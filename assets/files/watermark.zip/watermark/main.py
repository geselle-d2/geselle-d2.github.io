import tkinter
import os
from tkinter import filedialog
from PIL import Image, ImageTk
global mode

#used functions
#select image for watermarking
def import_image():
    global full_image
    global image_set
    try:
        window.filename = filedialog.askopenfilename(title="select a file",  filetype=(("png files", "*.png"),("jpg files", "*.jpg"),("all files", "*.*")))
        full_image = Image.open(window.filename)
        image_set = True
        image_preview()
    except:
        pass

#function to display image in gui
def image_preview():
    global preview_image
    global preview_image2
    global full_image
    preview_image = full_image.copy()   
    preview_image.thumbnail((500,500))
    preview_image2 = ImageTk.PhotoImage(preview_image)
    canvas = tkinter.Canvas(width = 500, height = 500)
    canvas.create_image(250, 250, image = preview_image2)
    canvas.grid(row=2, column=0, columnspan = 3, pady=(30,30))
    
    
    #tracking data types
    test_image = ImageTk.PhotoImage(full_image)
    print(type(test_image))
    print(type(preview_image))
    print(type(preview_image2))
    print(type(full_image))
#select image as watermark
def import_watermark():
    global watermark
    global mode

    global full_image
    global preview_image
    global marked_image
    try:
        file_location = filedialog.askopenfilename(title="select a file",  filetype=(("png files", "*.png"),("jpg files", "*.jpg"),("all files", "*.*")))
        watermark = Image.open(file_location)
        watermark.thumbnail((int(full_image.size[0]*0.2),int(full_image.size[1]*0.2)))
        #watermark.putalpha(128)
        if mode == 1:
            full_image.paste(watermark, (full_image.size[0]-watermark.size[0],full_image.size[1]-watermark.size[1]))
        if mode == 2:
           full_image.paste(watermark, (0,full_image.size[1]-watermark.size[1]))
        if mode == 3:
           full_image.paste(watermark, (full_image.size[0]-watermark.size[0],0))
        else:
           pass

        image_preview()
    except:
        pass

#function that creates a preview of the image on a separate window
        
def preview_window():
    
    global preview_image3
    global preview_image4
    global full_image
    
    if image_set == True:
        try:
            x = full_image.size[0]
            y = full_image.size[1]
            new_window = tkinter.Toplevel(window)
            new_window.title("Watermark preview")
            new_window.geometry(f"{x+30}x{y+50}")
            
            preview_image3 = full_image.copy()   
            preview_image4 = ImageTk.PhotoImage(preview_image3)
            canvas2 = tkinter.Canvas(new_window, width = x, height = y)
            canvas2.create_image(x/2, y/2, image = preview_image4)
            canvas2.grid(row=0, column=0, pady=(30,30), padx=(15,15))
        
        except:
            pass
    else:
        pass
    
   
    

#saves the image in a separate file. note: image on the gui is only a scaled preview and not the actual image being saved.
def save_image():
    global full_image
    save_location = filedialog.asksaveasfilename()
    try:
        full_image.save(save_location)
        os.remove("temp0101.png")
    except:
         try:
             save_location=save_location+".jpg"
             full_image = full_image.convert("RGB")
             full_image.save(save_location)
         except:
            pass
    else:
        pass




#mode selection for list box elements. selected mode defines where stamp is placed
def list_box_used(event):
    global mode
    if list_box.get(list_box.curselection()) == "Stamp mode, bottom left":
        mode = 2
    elif list_box.get(list_box.curselection()) == "Stamp mode, bottom right":
        mode = 1
    elif list_box.get(list_box.curselection()) == "Stamp mode, top right":
        mode = 3
    print(list_box.get(list_box.curselection()))





#main window and title
window = tkinter.Tk()
window.title("Add a watermark to an image")
window.minsize(width=700, height=700)
window.config(padx = 30, pady=50)
#title
my_label = tkinter.Label(text="Watermarker", font=("Arial", 24, "bold"))
my_label.grid(column = 1, row=0,pady=(0,25))

mode = 1
#image_set = False

#gui elements
#buttons
import_img_button = tkinter.Button(text="import image", command=import_image)
import_img_button.grid(row = 1, column=0)

import_wm_button = tkinter.Button(text="import watermark", command=import_watermark)
import_wm_button.grid(row = 1, column=2)

#list box
list_box=tkinter.Listbox(height = 4, width = 45)
watermark_methods =["Stamp mode, bottom right", "Stamp mode, bottom left", "Stamp mode, top right" ]
for item in watermark_methods:
    list_box.insert(watermark_methods.index(item), item)
list_box.bind("<<ListboxSelect>>", list_box_used)

list_box.grid(row = 3, column = 0, columnspan = 3)

#preview button
preview_button = tkinter.Button(text ="Preview watermarked image", command=preview_window)
preview_button.grid(row = 4, column =1)

save_button = tkinter.Button(text = "save image", command=save_image)
save_button.grid(row= 5, column =1)



window.mainloop()