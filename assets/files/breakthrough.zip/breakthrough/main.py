from turtle import Screen, Turtle
from paddle import Paddle
from ball import Ball
from block import Block
from score import Score
import time

screen = Screen()
screen.bgcolor("black")
screen.setup(width=600, height=800)
screen.title("Blocker")
screen.tracer(0)
def start_ball():
    start_ball = True

paddle = Paddle((0, -350))

ball = Ball()
ball.reset_position()


score = Score()
screen.listen()
screen.onkey(paddle.go_left, "a")
screen.onkey(paddle.go_right, "d")
#----------------------------------------------------------------------------------------------------------------
#level creation
level = []
for item in range (0,6):
    level.append(Block((-250+item*100, 150)))
for item in range (0, 3):
    level.append(Block((-200+item*170, 250)))
#-------------------------------------------------------------------------------------------------------------------
#-------------------------------------------------------------------------------------------------------------------
#game-loop

game_is_on = True

while game_is_on:
    time.sleep(0.00001)
    screen.update()
    ball.move()
    for item in level:
        if ball.distance(item) < 40:
            if abs(ball.xcor() - item.xcor())/2 > abs(ball.ycor()-item.ycor()):
                ball.x_bounce()

            else:
                ball.y_bounce()

            print(item.xcor())
            print(ball.xcor())
            level.remove(item)
            item.goto(700,800)
            score.point()

            #if len(level) == 0:
            # newlevel
    ball_hits_paddle = paddle.xcor()+55 > ball.xcor() > paddle.xcor()-55
    ball_in_front  = -350 < ball.ycor() < -330
    if ball.y_move < 1 and ball_in_front == True  and ball_hits_paddle == True:
        if ball.xcor() < paddle.xcor():
           if ball.xcor() + 25 < paddle.xcor():
               ball.paddle_bounce(-3,3)

           else:
                ball.paddle_bounce(-1.5,3)

        elif ball.xcor() > paddle.xcor():
            if ball.xcor() - 25 > paddle.xcor():
               ball.paddle_bounce(3,3)

            else:
                ball.paddle_bounce(1.5,3)


        else:
            ball.paddle_bounce(0,3)

    if ball.xcor() > 290:
        ball.x_bounce()
    if ball.xcor() < -290:
        ball.x_bounce()
    if ball.ycor() > 370:
        ball.y_bounce()
    if ball.ycor() < -420:
        ball.game_over()
        score.game_over()
        game_is_on = False
screen.exitonclick()

#-------------------------------------------------------------------------------------------------------------------