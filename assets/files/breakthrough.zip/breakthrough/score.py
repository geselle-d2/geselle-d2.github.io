from turtle import Turtle


class Score(Turtle):

    def __init__(self):
        super().__init__()
        self.color("red")
        self.penup()
        self.hideturtle()
        self.score = 0

        self.set_score()

    def set_score(self):
        self.clear()
        self.goto(-200,350)
        self.write(f'Score: {self.score}', align="center", font=("Courier", 25, "normal"))


    def point(self):
        self.score += 1
        self.set_score()

    def game_over(self):
        self.clear()
        self.goto(0,0)
        self.write(f'''GAME OVER
        '''
        , align="center", font=("Courier", 45, "normal"))

        self.write(f'')
        self.write(f' Your Score: {self.score}', align="center", font=("Courier", 25, "normal"))